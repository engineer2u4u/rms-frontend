/* global React, UI */
const { useState, useMemo } = React;
const { Icon, ICO, MatchCircle, MatchBar, StatusBadge, Avatar } = window.UI;

/* ---------- Sidebar ---------- */
function Sidebar({ route, setRoute, role, sidebarStyle, tenant, counts }) {
  const tenantNav = [
  { id: "dashboard", label: "Home", ico: ICO.dash },
  { id: "clients", label: "Clients", ico: ICO.clients, count: counts.clients },
  { id: "projects", label: "Projects", ico: ICO.projects, count: counts.openProjects },
  { id: "resources", label: "Resources", ico: ICO.resources, count: counts.resources },
  { id: "assignments", label: "Assignments", ico: ICO.assign, count: counts.assignments }];

  const adminNav = [
  { id: "admin-tenants", label: "Tenants", ico: ICO.clients, count: counts.tenants },
  { id: "admin-usage", label: "Usage", ico: ICO.spark },
  { id: "admin-billing", label: "Billing", ico: ICO.billing },
  { id: "admin-audit", label: "Audit log", ico: ICO.doc }];

  const nav = role === "admin" ? adminNav : tenantNav;
  const sectionLabel = role === "admin" ? "Platform" : "Workspace";

  return (
    <aside className={`sidebar ${sidebarStyle === "icon" ? "icon-only" : ""}`} style={{ backgroundColor: "rgb(56, 72, 124)", color: "rgb(255, 255, 255)" }}>
      <div className="sidebar-head">
        <span className="brand-mark">R</span>
        <span className="brand-name">Roster</span>
        {role === "admin" ? <span className="tenant-pill">Admin</span> :
        <span className="tenant-pill" title={tenant.name}>{"\n"}</span>}
      </div>

      <div className="nav-section">
        <div className="nav-label" style={{ color: "rgb(255, 255, 255)" }}>{sectionLabel}</div>
        {nav.map((n) =>
        <button key={n.id} className={`nav-item ${route === n.id ? "active" : ""}`} onClick={() => setRoute(n.id)}>
            <Icon d={n.ico} />
            <span>{n.label}</span>
            {n.count != null && <span className="count">{n.count}</span>}
          </button>
        )}
      </div>

      {role !== "admin" &&
      <div className="nav-section">
          <div className="nav-label">Pinned</div>
          <button className="nav-item" onClick={() => setRoute("projects")}>
            <span className="dot accent" />
            <span>Northwind Bank · Kafka</span>
          </button>
          <button className="nav-item" onClick={() => setRoute("projects")}>
            <span className="dot warn" />
            <span>Lumen Health · FHIR</span>
          </button>
          <button className="nav-item" onClick={() => setRoute("projects")}>
            <span className="dot info" />
            <span>Cobalt · Snowflake</span>
          </button>
        </div>
      }

      <div className="sidebar-foot">
        <div className="row gap-2" style={{ alignItems: "center", padding: 6 }}>
          <Avatar name="You" color={0} />
          <div className="col" style={{ flex: 1, minWidth: 0 }}>
            <div className="text-sm bold ellipsis">Hana Park</div>
            <div className="text-xs muted ellipsis">Senior Resourcer</div>
          </div>
          <Icon d={ICO.more} />
        </div>
      </div>
    </aside>);

}

/* ---------- Topbar ---------- */
function Topbar({ crumbs, role, setRole, onSearch, onAddResource }) {
  return (
    <header className="topbar">
      <div className="crumbs">
        {crumbs.map((c, i) =>
        <React.Fragment key={i}>
            {i > 0 && <span className="sep">/</span>}
            <span className={i === crumbs.length - 1 ? "curr" : ""}>{c}</span>
          </React.Fragment>
        )}
      </div>
      <div className="topbar-spacer" />
      <div className="search-box">
        <Icon d={ICO.search} size={12} />
        <span>Search clients, projects, people…</span>
        <kbd>⌘K</kbd>
      </div>
      <div className="role-switch" title="Switch persona">
        <button className={role === "consultant" ? "active" : ""} onClick={() => setRole("consultant")}>Consultant</button>
        <button className={role === "admin" ? "active" : ""} onClick={() => setRole("admin")}>Super-admin</button>
      </div>
      {role !== "admin" &&
      <button className="btn accent" onClick={onAddResource}>
          <Icon d={ICO.plus} /> Add resource
        </button>
      }
      <button className="btn ghost" style={{ width: 28, padding: 0, justifyContent: "center" }}>
        <Icon d={ICO.bell} />
      </button>
    </header>);

}

window.Shell = { Sidebar, Topbar };