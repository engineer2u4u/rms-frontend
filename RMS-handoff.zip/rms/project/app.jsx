/* global React, ReactDOM, UI, Shell, RMS_DATA,
   DashboardView, ClientsView, ProjectsView, ResourcesView, AssignmentsView,
   AdminView, AddResourceModal, ResourceDrawer, ProjectDrawer,
   TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakSelect, TweakColor, TweakToggle */
const { useState, useEffect } = React;
const D = window.RMS_DATA;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "#5566F2",
  "matchStyle": "circle",
  "sidebarStyle": "labeled",
  "projectsLayout": "list",
  "resourcesLayout": "table",
  "density": "comfortable"
}/*EDITMODE-END*/;

function App() {
  const [route, setRoute] = useState("dashboard");
  const [role, setRole] = useState("consultant"); // consultant | admin
  const [openResource, setOpenResource] = useState(null);
  const [openResourceProject, setOpenResourceProject] = useState(null);
  const [openProject, setOpenProject] = useState(null);
  const [openClient, setOpenClient] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [matchProject, setMatchProject] = useState("p1");
  const [toast, setToast] = useState(null);

  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply tweaks to CSS variables
  useEffect(() => {
    const root = document.documentElement;
    if (t.theme === "dark") root.setAttribute("data-theme", "dark");
    else root.removeAttribute("data-theme");
    if (t.accent) {
      // convert hex → set as accent
      root.style.setProperty("--accent", t.accent);
      // soft variant via mix
      root.style.setProperty("--accent-2", t.accent);
      root.style.setProperty("--accent-soft", `color-mix(in oklch, ${t.accent} 12%, white)`);
      root.style.setProperty("--accent-border", `color-mix(in oklch, ${t.accent} 30%, white)`);
    }
    if (t.density === "compact") {
      root.style.setProperty("--topbar-h", "44px");
      document.body.style.fontSize = "12.5px";
    } else {
      root.style.setProperty("--topbar-h", "48px");
      document.body.style.fontSize = "13px";
    }
  }, [t.accent, t.density, t.theme]);
  useEffect(() => {
    if (role === "admin" && !route.startsWith("admin")) setRoute("admin-tenants");
    if (role === "consultant" && route.startsWith("admin")) setRoute("dashboard");
  }, [role]);

  // Show toast helper
  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }

  // ---- Routing ----
  const tenant = D.TENANTS[0];
  const counts = {
    clients: D.CLIENTS.length,
    openProjects: D.PROJECTS.filter(p => !["filled","lost"].includes(p.status)).length,
    resources: D.RESOURCES.length,
    assignments: D.ASSIGNMENTS.length,
    tenants: D.TENANTS.length,
  };

  const crumbsMap = {
    "dashboard":   ["Home"],
    "clients":     ["Clients"],
    "projects":    ["Projects"],
    "resources":   ["Resources"],
    "assignments": ["Assignments"],
    "admin-tenants":["Admin", "Tenants"],
    "admin-usage":  ["Admin", "Usage"],
    "admin-billing":["Admin", "Billing"],
    "admin-audit":  ["Admin", "Audit log"],
  };

  // Inject openClient as a synthetic page when set
  let mainView;
  if (role === "admin") {
    mainView = <AdminView route={route}/>;
  } else if (route === "dashboard") {
    mainView = <DashboardView onNav={setRoute}/>;
  } else if (route === "clients") {
    mainView = <ClientsView onOpenClient={c => { setOpenClient(c); showToast(`Opened ${c.name}`); }}/>;
  } else if (route === "projects") {
    mainView = <ProjectsView onOpenProject={setOpenProject} layout={t.projectsLayout}/>;
  } else if (route === "resources") {
    mainView = <ResourcesView onOpenResource={r => { setOpenResource(r); setOpenResourceProject(matchProject ? D.PROJECTS.find(p => p.id === matchProject) : null); }} matchProject={matchProject} setMatchProject={setMatchProject} matchStyle={t.matchStyle} layout={t.resourcesLayout}/>;
  } else if (route === "assignments") {
    mainView = <AssignmentsView
      onOpenResource={(r, p) => { setOpenResource(r); setOpenResourceProject(p); }}
      onOpenProject={setOpenProject}/>;
  }

  return (
    <div className="app">
      <Shell.Sidebar
        route={route} setRoute={setRoute}
        role={role}
        sidebarStyle={t.sidebarStyle}
        tenant={tenant}
        counts={counts}/>

      <div className="main">
        <Shell.Topbar
          crumbs={crumbsMap[route] || ["Home"]}
          role={role} setRole={setRole}
          onAddResource={() => setShowAdd(true)}/>

        <div className="page">{mainView}</div>
      </div>

      {openResource && (
        <ResourceDrawer
          resource={openResource}
          project={openResourceProject}
          onClose={() => { setOpenResource(null); setOpenResourceProject(null); }}/>
      )}

      {openProject && (
        <ProjectDrawer
          project={openProject}
          onClose={() => setOpenProject(null)}
          onMatchSearch={(pid) => { setMatchProject(pid); setRoute("resources"); setOpenProject(null); showToast("Resources filtered to top matches"); }}/>
      )}

      {openClient && (
        <ClientDrawer client={openClient} onClose={() => setOpenClient(null)} onOpenProject={p => { setOpenClient(null); setOpenProject(p); }}/>
      )}

      {showAdd && (
        <AddResourceModal
          onClose={() => setShowAdd(false)}
          onCreated={() => showToast("Lucas Marchetti added to bench")}/>
      )}

      {/* Tweaks */}
      <TweaksPanel title="Tweaks">
        <TweakSection title="Theme">
          <TweakRadio label="Mode" value={t.theme} onChange={v => setTweak("theme", v)}
            options={[{value:"light",label:"Light"},{value:"dark",label:"Dark"}]}/>
          <TweakColor label="Accent" value={t.accent} onChange={v => setTweak("accent", v)}
            options={["#5566F2","#0EA5B7","#D97757","#1F8A5B","#7C3AED","#111111"]}/>
          <TweakRadio label="Density" value={t.density} onChange={v => setTweak("density", v)}
            options={[{value:"comfortable",label:"Comfy"},{value:"compact",label:"Compact"}]}/>
          <TweakRadio label="Sidebar" value={t.sidebarStyle} onChange={v => setTweak("sidebarStyle", v)}
            options={[{value:"labeled",label:"Labeled"},{value:"icon",label:"Icon-only"}]}/>
        </TweakSection>
        <TweakSection title="Resources view">
          <TweakSelect label="Match score style" value={t.matchStyle} onChange={v => setTweak("matchStyle", v)}
            options={[{value:"circle",label:"Circular %"},{value:"bar",label:"Bar with score"},{value:"chip",label:"Color chip"}]}/>
          <TweakRadio label="Layout" value={t.resourcesLayout} onChange={v => setTweak("resourcesLayout", v)}
            options={[{value:"table",label:"Table"},{value:"cards",label:"Cards"}]}/>
        </TweakSection>
        <TweakSection title="Projects view">
          <TweakRadio label="Layout" value={t.projectsLayout} onChange={v => setTweak("projectsLayout", v)}
            options={[{value:"list",label:"List"},{value:"kanban",label:"Pipeline"}]}/>
        </TweakSection>
      </TweaksPanel>

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

/* ---------- Client drawer (inline; simple) ---------- */
function ClientDrawer({ client: c, onClose, onOpenProject }) {
  const { Icon, ICO, Avatar } = window.UI;
  const projects = D.PROJECTS.filter(p => p.client === c.id);
  return (
    <>
      <div className="drawer-backdrop" onClick={onClose}/>
      <div className="drawer">
        <div className="drawer-head">
          <Avatar name={c.name} color={c.logoColor} size="lg"/>
          <div className="col flex-grow">
            <div className="text-lg bold">{c.name}</div>
            <div className="text-xs muted">{c.industry} · {c.location} · Client since {c.since}</div>
          </div>
          {c.health === "good" && <span className="badge ok"><span className="dot"/>Healthy</span>}
          {c.health === "attention" && <span className="badge warn"><span className="dot"/>Attention</span>}
          {c.health === "risk" && <span className="badge danger"><span className="dot"/>At risk</span>}
          <button className="btn ghost" onClick={onClose} style={{ width: 28, padding: 0, justifyContent: "center" }}><Icon d={ICO.x}/></button>
        </div>
        <div className="drawer-body col gap-5">
          <div className="grid-4">
            <div className="stat"><div className="stat-label">Open reqs</div><div className="stat-value">{c.openProjects}</div></div>
            <div className="stat"><div className="stat-label">Active assignments</div><div className="stat-value">{c.activeAssignments}</div></div>
            <div className="stat"><div className="stat-label">Primary contact</div><div className="text-sm bold" style={{marginTop:4}}>{c.contact}</div></div>
            <div className="stat"><div className="stat-label">Industry</div><div className="text-sm bold" style={{marginTop:4}}>{c.industry}</div></div>
          </div>
          <div>
            <div className="text-sm bold" style={{marginBottom:8}}>Requirements ({projects.length})</div>
            <div className="table-wrap">
              <table className="tbl">
                <thead><tr><th>Title</th><th className="right">Roles</th><th>Status</th><th>Rate</th></tr></thead>
                <tbody>
                  {projects.map(p => {
                    const stDef = D.PROJECT_STATUSES.find(s => s.id === p.status);
                    return (
                      <tr key={p.id} className="clickable" onClick={() => onOpenProject(p)}>
                        <td className="bold">{p.title}</td>
                        <td className="right num">{p.roles}</td>
                        <td><span className={`badge ${stDef.color}`}><span className="dot"/>{stDef.label}</span></td>
                        <td className="mono text-xs">{p.rate}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(<App/>);
