/* global React, UI, RMS_DATA */
const { useState, useMemo } = React;
const { Icon, ICO, MatchCircle, MatchBar, StatusBadge, Avatar } = window.UI;
const D = window.RMS_DATA;

/* ---------- Resource detail drawer ---------- */
function ResourceDrawer({ resource, project, onClose }) {
  const [tab, setTab] = useState("overview");
  const m = project ? D.matchScore(resource, project) : null;
  const r = resource;
  const stDef = D.STATUSES.find(s => s.id === r.status);

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <div className="drawer">
        <div className="drawer-head">
          <Avatar name={r.name} color={r.avatarColor} size="lg" />
          <div className="col flex-grow">
            <div className="text-lg bold">{r.name}</div>
            <div className="text-xs muted">{r.seniority} · {r.role} · {r.location}</div>
          </div>
          <button className="btn"><Icon d={ICO.mail}/> Message</button>
          <button className="btn accent"><Icon d={ICO.send}/> Share profile</button>
          <button className="btn ghost" onClick={onClose} style={{ width: 28, padding: 0, justifyContent: "center" }}><Icon d={ICO.x}/></button>
        </div>

        <div style={{borderBottom:"1px solid var(--border)", padding:"0 24px"}}>
          <div className="tab-bar">
            {["overview","matching","experience","activity"].map(t => (
              <div key={t} className={`tab ${tab === t ? "active" : ""}`} onClick={() => setTab(t)}>{t[0].toUpperCase()+t.slice(1)}</div>
            ))}
          </div>
        </div>

        <div className="drawer-body">
          {tab === "overview" && (
            <div className="col gap-5">
              <div className="row gap-4">
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Status</div>
                  <span className={`badge ${stDef.color}`} style={{alignSelf:"flex-start"}}><span className="dot"/>{stDef.label}</span>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Available</div>
                  <div className="text-sm bold">{r.availability}</div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Rate</div>
                  <div className="text-sm bold mono">{r.rate} <span className="muted">{r.currency}</span></div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Experience</div>
                  <div className="text-sm bold">{r.yrs} years</div>
                </div>
              </div>

              <div className="col gap-2">
                <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Summary</div>
                <div className="text-sm" style={{lineHeight:1.6}}>{r.bio}</div>
              </div>

              <div className="col gap-2">
                <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Skills</div>
                <div className="row gap-2" style={{flexWrap:"wrap"}}>
                  {r.skills.map(s => {
                    const matched = project && project.skills.some(ps => ps.toLowerCase() === s.toLowerCase());
                    return <span key={s} className={`skill-tag ${matched ? "match" : ""}`}>{s}</span>;
                  })}
                </div>
              </div>

              <div className="row gap-4">
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Languages</div>
                  <div className="text-sm">{r.languages.join(" · ")}</div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Notice period</div>
                  <div className="text-sm">{r.noticePeriod || 0} weeks</div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Engagement</div>
                  <div className="text-sm">{r.engagement}</div>
                </div>
              </div>

              {r.tags.length > 0 && (
                <div className="col gap-2">
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Tags</div>
                  <div className="row gap-2">
                    {r.tags.map(t => <span key={t} className="chip">{t}</span>)}
                  </div>
                </div>
              )}
            </div>
          )}

          {tab === "matching" && (
            <div className="col gap-5">
              {m ? (
                <>
                  <div className="row gap-4" style={{alignItems:"center"}}>
                    <MatchCircle score={m.total} size={80} />
                    <div className="col">
                      <div className="text-lg bold">Matched against {project.title}</div>
                      <div className="text-xs muted">{D.CLIENTS.find(c => c.id === project.client).name}</div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="card-head"><div className="card-title">Score breakdown</div></div>
                    <div className="card-body col gap-3">
                      <MatchBar label="Skills" score={m.skill} />
                      <MatchBar label="Experience" score={m.exp} />
                      <MatchBar label="Availability" score={m.avail} />
                      <MatchBar label="Location" score={m.loc} />
                    </div>
                  </div>

                  <div className="grid-2">
                    <div className="card">
                      <div className="card-head"><div className="card-title">Matched skills <span className="text-xs muted" style={{marginLeft:6}}>({m.matchedSkills.length})</span></div></div>
                      <div className="card-body row gap-2" style={{flexWrap:"wrap"}}>
                        {m.matchedSkills.map(s => <span key={s} className="skill-tag match">{s}</span>)}
                      </div>
                    </div>
                    <div className="card">
                      <div className="card-head"><div className="card-title">Missing skills <span className="text-xs muted" style={{marginLeft:6}}>({m.missingSkills.length})</span></div></div>
                      <div className="card-body row gap-2" style={{flexWrap:"wrap"}}>
                        {m.missingSkills.length ? m.missingSkills.map(s => <span key={s} className="skill-tag miss">{s}</span>) : <span className="text-xs muted">All required skills present.</span>}
                      </div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="card-head"><div className="card-title">Top 3 reasons</div></div>
                    <ol style={{margin:0,padding:"12px 16px 16px 28px",display:"flex",flexDirection:"column",gap:8}}>
                      <li className="text-sm">{m.matchedSkills.length} of {project.skills.length} required skills are explicitly present in profile.</li>
                      <li className="text-sm">{r.yrs} years of experience meets the seniority bar for this requirement.</li>
                      <li className="text-sm">Availability ({r.availability}) {m.avail >= 80 ? "aligns with" : "is acceptable for"} the {project.start.slice(5)} start date.</li>
                    </ol>
                  </div>
                </>
              ) : (
                <div className="empty">
                  <Icon d={ICO.spark} size={24} />
                  <div>Pick a project at the top of the resources list to see this resource's match breakdown.</div>
                </div>
              )}
            </div>
          )}

          {tab === "experience" && (
            <div className="col gap-3">
              {[
                { co: "Currently consulting via Roster", role: r.role, from: "2024", to: "Present" },
                { co: "Prior engagement (client name hidden)", role: r.role, from: "2021", to: "2024" },
                { co: "Earlier role", role: r.role.includes("Senior") ? r.role.replace("Senior ","") : r.role, from: "2018", to: "2021" },
              ].map((e, i) => (
                <div key={i} className="row gap-3" style={{padding:14,border:"1px solid var(--border)",borderRadius:8}}>
                  <div className="col" style={{flex:1}}>
                    <div className="bold text-sm">{e.role}</div>
                    <div className="text-xs muted">{e.co}</div>
                  </div>
                  <div className="text-xs mono muted">{e.from} – {e.to}</div>
                </div>
              ))}
              <div className="row gap-3" style={{padding:14,border:"1px solid var(--border)",borderRadius:8,alignItems:"center"}}>
                <Icon d={ICO.doc} />
                <div className="col" style={{flex:1}}>
                  <div className="text-sm">Resume_{r.name.replace(" ","_")}_v3.pdf</div>
                  <div className="text-xs muted">Uploaded {r.lastUpdated} · 248 KB</div>
                </div>
                <button className="btn"><Icon d={ICO.download}/> Download</button>
              </div>
            </div>
          )}

          {tab === "activity" && (
            <div className="col gap-2">
              {[
                { when: "2d ago", what: "Added to shortlist for Northwind Bank Kafka role", who: "you" },
                { when: "1w ago", what: "Updated availability to 'Available soon'", who: "system" },
                { when: "3w ago", what: "Profile shared with Aster Insurance", who: "Anika Sharma" },
                { when: "1mo ago", what: "Resume v3 parsed and merged into profile", who: "system" },
              ].map((a, i) => (
                <div key={i} className="row gap-3" style={{padding:"10px 0", borderBottom:"1px solid var(--border)"}}>
                  <span className="dot accent" style={{marginTop:6}}/>
                  <div className="col flex-grow">
                    <div className="text-sm">{a.what}</div>
                    <div className="text-xs muted">{a.who} · {a.when}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {project && (
          <div className="drawer-foot">
            <button className="btn">Add note</button>
            <button className="btn">Move to interview</button>
            <button className="btn accent"><Icon d={ICO.send}/> Share with {D.CLIENTS.find(c => c.id === project.client).name}</button>
          </div>
        )}
      </div>
    </>
  );
}

/* ---------- Project detail drawer ---------- */
function ProjectDrawer({ project, onClose, onMatchSearch }) {
  const [tab, setTab] = useState("overview");
  const p = project;
  const c = D.CLIENTS.find(x => x.id === p.client);
  const stDef = D.PROJECT_STATUSES.find(s => s.id === p.status);
  const assignments = D.ASSIGNMENTS.filter(a => a.project === p.id);
  const topMatches = useMemo(() => D.RESOURCES.map(r => ({ r, m: D.matchScore(r, p) }))
    .sort((a, b) => b.m.total - a.m.total).slice(0, 8), [p.id]);

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <div className="drawer" style={{ width: "min(780px, 92vw)" }}>
        <div className="drawer-head">
          <Avatar name={c.name} color={c.logoColor} size="lg" />
          <div className="col flex-grow">
            <div className="text-lg bold">{p.title}</div>
            <div className="text-xs muted">{c.name} · {p.location} · {p.duration} · starts {p.start}</div>
          </div>
          <span className={`badge ${stDef.color}`}><span className="dot"/>{stDef.label}</span>
          <button className="btn ghost" onClick={onClose} style={{ width: 28, padding: 0, justifyContent: "center" }}><Icon d={ICO.x}/></button>
        </div>

        {/* Pipeline progress strip */}
        <div style={{ padding: "12px 24px", borderBottom:"1px solid var(--border)" }}>
          <div className="row" style={{ gap: 4, alignItems:"center" }}>
            {D.PROJECT_STATUSES.filter(s => !["lost","hold"].includes(s.id)).map((s, i, arr) => {
              const idx = arr.findIndex(x => x.id === p.status);
              const myIdx = i;
              const isActive = s.id === p.status;
              const passed = myIdx <= idx;
              return (
                <React.Fragment key={s.id}>
                  <div className="col" style={{ alignItems:"center", flex:1, gap:4 }}>
                    <div style={{
                      width: 18, height: 18, borderRadius: "50%",
                      background: passed ? "var(--accent)" : "var(--surface-2)",
                      border: "2px solid " + (isActive ? "var(--accent)" : passed ? "var(--accent)" : "var(--border)"),
                      boxShadow: isActive ? "0 0 0 4px var(--accent-soft)" : "none"
                    }} />
                    <span className="text-xs" style={{ color: isActive ? "var(--text)" : "var(--text-3)", fontWeight: isActive ? 600 : 400 }}>{s.label}</span>
                  </div>
                  {i < arr.length - 1 && <div style={{ height: 2, flex: 1, background: myIdx < idx ? "var(--accent)" : "var(--border)", marginBottom: 18 }}/>}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        <div style={{borderBottom:"1px solid var(--border)", padding:"0 24px"}}>
          <div className="tab-bar">
            {["overview", `candidates (${assignments.length})`, `matches (${topMatches.length})`, "activity"].map(t => (
              <div key={t} className={`tab ${tab === t.split(" ")[0] ? "active" : ""}`} onClick={() => setTab(t.split(" ")[0])}>{t}</div>
            ))}
          </div>
        </div>

        <div className="drawer-body">
          {tab === "overview" && (
            <div className="col gap-5">
              <div className="row gap-4">
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Roles</div>
                  <div className="text-sm bold num">{p.roles}</div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Rate</div>
                  <div className="text-sm bold mono">{p.rate}</div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Duration</div>
                  <div className="text-sm bold">{p.duration}</div>
                </div>
                <div className="col gap-2" style={{flex:1}}>
                  <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Owner</div>
                  <div className="text-sm bold">{p.owner === "you" ? "You" : p.owner}</div>
                </div>
              </div>

              <div className="col gap-2">
                <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Brief</div>
                <div className="text-sm" style={{lineHeight:1.6}}>{p.desc}</div>
              </div>

              <div className="col gap-2">
                <div className="text-xs muted" style={{textTransform:"uppercase",letterSpacing:".06em"}}>Required skills</div>
                <div className="row gap-2" style={{flexWrap:"wrap"}}>
                  {p.skills.map(s => <span key={s} className="skill-tag match">{s}</span>)}
                </div>
              </div>

              <button className="btn accent" style={{alignSelf:"flex-start"}} onClick={() => onMatchSearch(p.id)}>
                <Icon d={ICO.spark}/> Find matching resources
              </button>
            </div>
          )}

          {tab === "candidates" && (
            <div className="table-wrap">
              <table className="tbl">
                <thead><tr><th>Candidate</th><th className="right">Match</th><th>Status</th><th>Shared</th><th>Notes</th></tr></thead>
                <tbody>
                  {assignments.map(a => {
                    const res = D.RESOURCES.find(x => x.id === a.resource);
                    const ast = D.ASSIGNMENT_STATUSES.find(s => s.id === a.status);
                    return (
                      <tr key={a.id}>
                        <td>
                          <div className="row gap-2" style={{alignItems:"center"}}>
                            <Avatar name={res.name} color={res.avatarColor}/>
                            <div className="col">
                              <span className="bold">{res.name}</span>
                              <span className="text-xs muted">{res.seniority} · {res.role}</span>
                            </div>
                          </div>
                        </td>
                        <td className="right"><MatchCircle score={a.score}/></td>
                        <td><span className={`badge ${ast.color}`}><span className="dot"/>{ast.label}</span></td>
                        <td className="text-xs muted">{a.sharedAt}</td>
                        <td className="text-xs muted">{a.notes || "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {tab === "matches" && (
            <div className="col gap-2">
              <div className="row" style={{alignItems:"center"}}>
                <span className="text-sm muted">Top matches by composite score</span>
                <button className="btn sm" style={{marginLeft:"auto"}} onClick={() => onMatchSearch(p.id)}>Open full match search →</button>
              </div>
              {topMatches.map(({ r, m }) => (
                <div key={r.id} className="row gap-3" style={{padding:12,border:"1px solid var(--border)",borderRadius:8,alignItems:"center"}}>
                  <Avatar name={r.name} color={r.avatarColor} size="lg"/>
                  <div className="col flex-grow">
                    <div className="bold">{r.name}</div>
                    <div className="text-xs muted">{r.seniority} · {r.role} · {r.location}</div>
                    <div className="row gap-2" style={{marginTop:4, flexWrap:"wrap"}}>
                      {m.matchedSkills.slice(0,5).map(s => <span key={s} className="skill-tag match">{s}</span>)}
                      {m.missingSkills.slice(0,2).map(s => <span key={s} className="skill-tag miss">{s}</span>)}
                    </div>
                  </div>
                  <div className="col" style={{width:160, gap:4}}>
                    <MatchBar score={m.total}/>
                    <span className="text-xs muted">Skills {m.skill}% · Avail {m.avail}%</span>
                  </div>
                  <button className="btn">Shortlist</button>
                </div>
              ))}
            </div>
          )}

          {tab === "activity" && (
            <div className="col gap-2">
              {(D.ACTIVITY[p.id] || [
                { when: "Today", who: "you", what: "Reviewed project brief" },
                { when: "Yesterday", who: "system", what: "Auto-matched candidates" },
                { when: "2d ago", who: p.owner, what: "Project created" },
              ]).map((a, i) => (
                <div key={i} className="row gap-3" style={{padding:"10px 0", borderBottom:"1px solid var(--border)"}}>
                  <span className="dot accent" style={{marginTop:6}}/>
                  <div className="col flex-grow">
                    <div className="text-sm">{a.what}</div>
                    <div className="text-xs muted">{a.who} · {a.when}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

window.ResourceDrawer = ResourceDrawer;
window.ProjectDrawer = ProjectDrawer;
