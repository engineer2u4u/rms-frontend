/* global React, UI, RMS_DATA */
const { useState } = React;
const { Icon, ICO, Avatar } = window.UI;
const D = window.RMS_DATA;

function AdminView({ route }) {
  if (route === "admin-tenants") return <TenantsView />;
  if (route === "admin-usage")   return <UsageView />;
  if (route === "admin-billing") return <BillingView />;
  if (route === "admin-audit")   return <AuditView />;
  return <TenantsView />;
}

function TenantsView() {
  const [q, setQ] = useState("");
  const filtered = D.TENANTS.filter(t => t.name.toLowerCase().includes(q.toLowerCase()));
  const totalRev = D.TENANTS.reduce((s,t) => s + t.mrr, 0);
  const totalSeats = D.TENANTS.reduce((s,t) => s + t.used, 0);
  const totalResources = D.TENANTS.reduce((s,t) => s + t.resources, 0);

  return (
    <div className="col gap-4">
      <div className="page-head">
        <div>
          <h1 className="page-title">Tenants</h1>
          <div className="page-sub">{D.TENANTS.length} workspaces · {totalSeats} consultant seats · ${totalRev.toLocaleString()} MRR</div>
        </div>
        <div className="page-actions">
          <button className="btn"><Icon d={ICO.download}/> Export</button>
          <button className="btn accent"><Icon d={ICO.plus}/> Provision tenant</button>
        </div>
      </div>

      <div className="grid-4">
        <div className="stat"><div className="stat-label">Active tenants</div><div className="stat-value">{D.TENANTS.filter(t=>t.status==="active").length}</div><div className="stat-delta up">+1 this month</div></div>
        <div className="stat"><div className="stat-label">Total seats used</div><div className="stat-value">{totalSeats}</div><div className="stat-delta">of {D.TENANTS.reduce((s,t)=>s+t.seats,0)} provisioned</div></div>
        <div className="stat"><div className="stat-label">Resources on platform</div><div className="stat-value">{totalResources.toLocaleString()}</div><div className="stat-delta up">+8.2% MoM</div></div>
        <div className="stat"><div className="stat-label">MRR</div><div className="stat-value">${(totalRev/1000).toFixed(1)}k</div><div className="stat-delta up">+12.4% MoM</div></div>
      </div>

      <div className="row gap-3">
        <div className="search-box" style={{width:280,height:32,color:"var(--text)"}}>
          <Icon d={ICO.search} size={12}/>
          <input className="input" style={{border:0,padding:0,height:"auto",background:"transparent"}} placeholder="Search tenants…" value={q} onChange={e=>setQ(e.target.value)}/>
        </div>
        <button className="btn"><Icon d={ICO.filter}/> Filters</button>
      </div>

      <div className="table-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Tenant</th><th>Owner</th><th>Plan</th><th>Region</th>
              <th className="right">Seats</th><th className="right">Clients</th><th className="right">Resources</th>
              <th className="right">MRR</th><th>Joined</th><th>Status</th><th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => (
              <tr key={t.id} className="clickable">
                <td>
                  <div className="row gap-2" style={{alignItems:"center"}}>
                    <Avatar name={t.name} color={t.id.charCodeAt(1)%6}/>
                    <span className="bold">{t.name}</span>
                  </div>
                </td>
                <td className="muted">{t.owner}</td>
                <td>
                  {t.plan === "Enterprise" && <span className="badge accent"><span className="dot"/>Enterprise</span>}
                  {t.plan === "Scale" && <span className="badge info"><span className="dot"/>Scale</span>}
                  {t.plan === "Team" && <span className="badge neutral"><span className="dot"/>Team</span>}
                  {t.plan === "Starter" && <span className="badge neutral"><span className="dot"/>Starter</span>}
                </td>
                <td className="text-xs mono muted">{t.region}</td>
                <td className="right">
                  <span className="mono"><b>{t.used}</b><span className="muted">/{t.seats}</span></span>
                </td>
                <td className="right num">{t.clients}</td>
                <td className="right num">{t.resources}</td>
                <td className="right mono">${t.mrr.toLocaleString()}</td>
                <td className="mono text-xs muted">{t.joined}</td>
                <td>
                  {t.status === "active" && <span className="badge ok"><span className="dot"/>Active</span>}
                  {t.status === "trial"  && <span className="badge warn"><span className="dot"/>Trial</span>}
                  {t.status === "paused" && <span className="badge neutral"><span className="dot"/>Paused</span>}
                </td>
                <td><button className="btn sm ghost"><Icon d={ICO.more} size={12}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function UsageView() {
  return (
    <div className="col gap-4">
      <div className="page-head">
        <div>
          <h1 className="page-title">Usage</h1>
          <div className="page-sub">Platform health and per-tenant adoption signals</div>
        </div>
      </div>
      <div className="grid-4">
        <div className="stat"><div className="stat-label">DAU (consultants)</div><div className="stat-value">84</div><div className="stat-delta up">+12.1%</div></div>
        <div className="stat"><div className="stat-label">Searches / day</div><div className="stat-value">1,247</div><div className="stat-delta up">+6.4%</div></div>
        <div className="stat"><div className="stat-label">Profiles shared / day</div><div className="stat-value">312</div><div className="stat-delta up">+3.1%</div></div>
        <div className="stat"><div className="stat-label">Match runs / day</div><div className="stat-value">4,902</div><div className="stat-delta up">+18.7%</div></div>
      </div>

      <div className="card">
        <div className="card-head"><div className="card-title">Tenants by activity (this week)</div></div>
        <div className="card-body col gap-3">
          {[...D.TENANTS].sort((a,b)=>b.used-a.used).map((t, i) => {
            const pct = Math.min(100, (t.used / 60) * 100);
            return (
              <div key={t.id} className="row gap-3" style={{alignItems:"center"}}>
                <span className="text-xs muted mono" style={{width:18}}>{i+1}</span>
                <Avatar name={t.name} color={t.id.charCodeAt(1)%6}/>
                <span className="text-sm bold" style={{width:200}}>{t.name}</span>
                <div className="match-bar" style={{flex:1}}>
                  <div className="track"><div className="fill" style={{width:`${pct}%`,background:"var(--accent)"}}/></div>
                </div>
                <span className="text-xs mono muted" style={{width:80,textAlign:"right"}}>{t.used} active</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function BillingView() {
  return (
    <div className="col gap-4">
      <div className="page-head"><div><h1 className="page-title">Billing</h1><div className="page-sub">Invoices and revenue per tenant</div></div></div>
      <div className="table-wrap">
        <table className="tbl">
          <thead><tr><th>Tenant</th><th>Plan</th><th className="right">Seats billed</th><th className="right">MRR</th><th>Next invoice</th><th>Method</th><th>Status</th></tr></thead>
          <tbody>
            {D.TENANTS.map(t => (
              <tr key={t.id}>
                <td><div className="row gap-2" style={{alignItems:"center"}}><Avatar name={t.name} color={t.id.charCodeAt(1)%6}/><span className="bold">{t.name}</span></div></td>
                <td>{t.plan}</td>
                <td className="right num">{t.used}</td>
                <td className="right mono">${t.mrr.toLocaleString()}</td>
                <td className="text-xs mono muted">2026-06-01</td>
                <td className="text-xs muted">Card · Visa •• 4242</td>
                <td>{t.mrr > 0 ? <span className="badge ok"><span className="dot"/>Paid</span> : <span className="badge neutral"><span className="dot"/>No charge</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AuditView() {
  const events = [
    { when: "12m ago", who: "system@roster",   tenant: "Cascade Resourcing", what: "Provisioned 3 new seats" },
    { when: "1h ago",  who: "priya@northwind", tenant: "Northwind Talent",   what: "Created project for Halberg Industries" },
    { when: "2h ago",  who: "system@roster",   tenant: "Boreal Consulting",  what: "Trial extension auto-approved (+14d)" },
    { when: "3h ago",  who: "marcus@helix",    tenant: "Helix Staffing Co.", what: "Exported 47 resources to CSV" },
    { when: "Yesterday", who: "lin@vector",    tenant: "Vector Partners",    what: "Updated SSO config (Okta)" },
    { when: "Yesterday", who: "system@roster", tenant: "Meridian Source",    what: "Workspace paused: payment failure" },
    { when: "2d ago",  who: "devon@cascade",   tenant: "Cascade Resourcing", what: "Invited 8 new consultants" },
  ];
  return (
    <div className="col gap-4">
      <div className="page-head"><div><h1 className="page-title">Audit log</h1><div className="page-sub">Cross-tenant security and admin events</div></div></div>
      <div className="table-wrap">
        <table className="tbl">
          <thead><tr><th style={{width:120}}>When</th><th>Actor</th><th>Tenant</th><th>Event</th></tr></thead>
          <tbody>
            {events.map((e,i) => (
              <tr key={i}>
                <td className="text-xs mono muted">{e.when}</td>
                <td className="text-xs mono">{e.who}</td>
                <td>{e.tenant}</td>
                <td>{e.what}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

window.AdminView = AdminView;
