/* global React, UI, RMS_DATA */
const { useState, useMemo } = React;
const { Icon, ICO, StatusBadge, Avatar } = window.UI;
const D = window.RMS_DATA;

function ClientsView({ onOpenClient }) {
  const [q, setQ] = useState("");
  const [view, setView] = useState("table"); // table | cards

  const filtered = D.CLIENTS.filter(c => c.name.toLowerCase().includes(q.toLowerCase()) || c.industry.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="col gap-4">
      <div className="page-head">
        <div>
          <h1 className="page-title">Clients</h1>
          <div className="page-sub">{D.CLIENTS.length} active clients · {D.CLIENTS.reduce((s,c)=>s+c.openProjects,0)} open requirements</div>
        </div>
        <div className="page-actions">
          <button className="btn"><Icon d={ICO.download} /> Export</button>
          <button className="btn accent"><Icon d={ICO.plus} /> Add client</button>
        </div>
      </div>

      <div className="row gap-3" style={{ alignItems: "center" }}>
        <div className="search-box" style={{ width: 280, height: 32, color: "var(--text)" }}>
          <Icon d={ICO.search} size={12} />
          <input className="input" style={{ border: 0, padding: 0, height: "auto", background: "transparent" }}
                 placeholder="Search clients…" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <button className="btn"><Icon d={ICO.filter} /> Filters</button>
        <div style={{ flex: 1 }} />
        <div className="role-switch">
          <button className={view === "table" ? "active" : ""} onClick={() => setView("table")}>Table</button>
          <button className={view === "cards" ? "active" : ""} onClick={() => setView("cards")}>Cards</button>
        </div>
      </div>

      {view === "table" ? (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: "30%" }}>Client</th>
                <th>Industry</th>
                <th>Location</th>
                <th>Primary contact</th>
                <th className="right">Open reqs</th>
                <th className="right">Active assignments</th>
                <th>Since</th>
                <th>Health</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} className="clickable" onClick={() => onOpenClient(c)}>
                  <td>
                    <div className="row gap-2" style={{ alignItems: "center" }}>
                      <Avatar name={c.name} color={c.logoColor} />
                      <span className="bold">{c.name}</span>
                    </div>
                  </td>
                  <td className="muted">{c.industry}</td>
                  <td className="muted">{c.location}</td>
                  <td className="muted">{c.contact}</td>
                  <td className="right num">{c.openProjects}</td>
                  <td className="right num">{c.activeAssignments}</td>
                  <td className="mono text-xs muted">{c.since}</td>
                  <td>
                    {c.health === "good" && <span className="badge ok"><span className="dot"/>Healthy</span>}
                    {c.health === "attention" && <span className="badge warn"><span className="dot"/>Attention</span>}
                    {c.health === "risk" && <span className="badge danger"><span className="dot"/>At risk</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="grid-3">
          {filtered.map(c => (
            <button key={c.id} className="card" style={{ textAlign: "left", padding: 16, cursor: "pointer" }} onClick={() => onOpenClient(c)}>
              <div className="row gap-3" style={{ alignItems: "center", marginBottom: 12 }}>
                <Avatar name={c.name} color={c.logoColor} size="lg" />
                <div className="col">
                  <div className="bold">{c.name}</div>
                  <div className="text-xs muted">{c.industry} · {c.location}</div>
                </div>
              </div>
              <div className="row gap-4" style={{ borderTop: "1px solid var(--border)", paddingTop: 10 }}>
                <div className="col">
                  <div className="text-xs muted">Open</div>
                  <div className="num bold">{c.openProjects}</div>
                </div>
                <div className="col">
                  <div className="text-xs muted">Active</div>
                  <div className="num bold">{c.activeAssignments}</div>
                </div>
                <div className="col" style={{ marginLeft: "auto", alignItems: "flex-end" }}>
                  <div className="text-xs muted">Health</div>
                  <div className="text-sm">{c.health === "good" ? "● Healthy" : c.health === "attention" ? "● Attention" : "● At risk"}</div>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

window.ClientsView = ClientsView;
