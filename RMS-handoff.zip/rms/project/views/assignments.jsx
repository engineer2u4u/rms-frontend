/* global React, UI, RMS_DATA */
const { useState } = React;
const { Icon, ICO, MatchCircle, StatusBadge, Avatar } = window.UI;
const D = window.RMS_DATA;

function AssignmentsView({ onOpenResource, onOpenProject }) {
  const [statusF, setStatusF] = useState("all");

  const filtered = D.ASSIGNMENTS.filter(a => statusF === "all" || a.status === statusF);

  return (
    <div className="col gap-4">
      <div className="page-head">
        <div>
          <h1 className="page-title">Assignments</h1>
          <div className="page-sub">{D.ASSIGNMENTS.length} active resource-to-project pairings across the pipeline</div>
        </div>
        <div className="page-actions">
          <button className="btn"><Icon d={ICO.download}/> Export</button>
        </div>
      </div>

      <div className="row gap-2" style={{flexWrap:"wrap"}}>
        <button className="chip" style={statusF==="all"?{background:"var(--text)",color:"#fff",borderColor:"var(--text)"}:undefined} onClick={() => setStatusF("all")}>All <span className="num" style={{opacity:0.7}}>{D.ASSIGNMENTS.length}</span></button>
        {D.ASSIGNMENT_STATUSES.map(s => {
          const ct = D.ASSIGNMENTS.filter(a => a.status === s.id).length;
          return (
            <button key={s.id} className="chip" style={statusF===s.id?{background:"var(--text)",color:"#fff",borderColor:"var(--text)"}:undefined} onClick={() => setStatusF(s.id)}>
              <span className={`dot ${s.color}`}/>{s.label} <span className="num" style={{opacity:0.7}}>{ct}</span>
            </button>
          );
        })}
      </div>

      <div className="pipeline">
        {D.ASSIGNMENT_STATUSES.map(s => {
          const items = D.ASSIGNMENTS.filter(a => a.status === s.id);
          return (
            <div key={s.id} className="pipeline-col">
              <header>
                <span className={`dot ${s.color}`}/>
                <span>{s.label}</span>
                <span className="text-xs muted" style={{marginLeft:"auto"}}>{items.length}</span>
              </header>
              <div className="col-body">
                {items.map(a => {
                  const r = D.RESOURCES.find(x => x.id === a.resource);
                  const p = D.PROJECTS.find(x => x.id === a.project);
                  const c = D.CLIENTS.find(x => x.id === p.client);
                  return (
                    <div key={a.id} className="kanban-card" onClick={() => onOpenResource(r, p)}>
                      <div className="row gap-2" style={{alignItems:"center",marginBottom:6}}>
                        <Avatar name={r.name} color={r.avatarColor}/>
                        <div className="col" style={{flex:1,minWidth:0}}>
                          <div className="text-sm bold ellipsis">{r.name}</div>
                          <div className="text-xs muted ellipsis">{r.seniority} · {r.role}</div>
                        </div>
                        <MatchCircle score={a.score} size={32} />
                      </div>
                      <div className="row gap-2" style={{alignItems:"center",padding:"6px 8px",background:"var(--surface-2)",borderRadius:4}}>
                        <Avatar name={c.name} color={c.logoColor}/>
                        <div className="col" style={{flex:1,minWidth:0}}>
                          <div className="text-xs ellipsis">{c.name}</div>
                          <div className="text-xs muted ellipsis">{p.title}</div>
                        </div>
                      </div>
                      {a.notes && <div className="text-xs muted" style={{marginTop:6, fontStyle:"italic"}}>"{a.notes}"</div>}
                      <div className="text-xs muted" style={{marginTop:6}}>{a.sharedAt}</div>
                    </div>
                  );
                })}
                {items.length === 0 && <div className="empty text-xs">Empty</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.AssignmentsView = AssignmentsView;
