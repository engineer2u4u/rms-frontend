/* global React, UI, RMS_DATA */
const { useState, useMemo } = React;
const { Icon, ICO, Avatar } = window.UI;
const D = window.RMS_DATA;

/* ---------- Sparkline with gradient ---------- */
function GradSpark({ vals, color, gradId, w = 200, h = 44 }) {
  const max = Math.max(...vals), min = Math.min(...vals);
  const sx = (i) => (i / (vals.length - 1)) * w;
  const sy = (v) => h - ((v - min) / (max - min || 1)) * (h - 6) - 3;
  const pts = vals.map((v, i) => `${sx(i).toFixed(1)},${sy(v).toFixed(1)}`);
  const path = "M" + pts.join(" L");
  const area = `M0,${h} L${pts.join(" L")} L${w},${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.5"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gradId})`}/>
      <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

/* ---------- Mini bar-spark (for Bounce Rate look) ---------- */
function MiniBars({ vals, color, w = 200, h = 44 }) {
  const max = Math.max(...vals);
  const bw = w / vals.length * 0.6;
  const gap = w / vals.length * 0.4;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      {vals.map((v, i) => {
        const bh = (v / max) * (h - 4);
        return <rect key={i} x={i * (bw + gap) + gap/2} y={h - bh - 2} width={bw} height={bh} rx="1.5" fill={color}/>;
      })}
    </svg>
  );
}

/* ---------- Bar chart for Sales & Views ---------- */
function BarChart({ data, w = 700, h = 240 }) {
  const max = 70;
  const groupW = w / data.length;
  const barW = groupW * 0.28;
  const padTop = 20, padBot = 30;
  const innerH = h - padTop - padBot;
  return (
    <svg className="bar-chart-svg" viewBox={`0 0 ${w} ${h}`} style={{width:"100%",height:h}}>
      <defs>
        <linearGradient id="grad-orange-bar" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffc107"/>
          <stop offset="100%" stopColor="#ff7a00"/>
        </linearGradient>
        <linearGradient id="grad-blue-bar" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#00d4ff"/>
          <stop offset="100%" stopColor="#2196f3"/>
        </linearGradient>
      </defs>
      {[0, 20, 40, 60].map(y => (
        <g key={y}>
          <line x1="40" x2={w} y1={padTop + innerH - (y/max)*innerH} y2={padTop + innerH - (y/max)*innerH} stroke="var(--border)" strokeDasharray="3 3"/>
          <text x="30" y={padTop + innerH - (y/max)*innerH + 4} textAnchor="end" fontSize="11" fill="var(--text-3)" fontFamily="var(--font-mono)">{y}</text>
        </g>
      ))}
      {data.map((d, i) => {
        const cx = 50 + i * groupW;
        const salesH = (d.sales / max) * innerH;
        const viewsH = (d.views / max) * innerH;
        return (
          <g key={i}>
            <rect className="bar-sales" x={cx - barW - 2} y={padTop + innerH - salesH} width={barW} height={salesH} rx="3"/>
            <rect className="bar-views" x={cx + 2}        y={padTop + innerH - viewsH} width={barW} height={viewsH} rx="3"/>
            <text x={cx} y={h - 10} textAnchor="middle" fontSize="11" fill="var(--text-3)">{d.month}</text>
          </g>
        );
      })}
    </svg>
  );
}

/* ---------- Dashboard ---------- */
function Dashboard({ onNav }) {
  const openProjects = D.PROJECTS.filter(p => !["filled","lost","hold"].includes(p.status));
  const availableNow = D.RESOURCES.filter(r => r.status === "available").length;

  const statCards = [
    { label: "Open requirements", value: openProjects.length, delta: "+24%", up: true, color: "blue",   icon: ICO.projects, spark: [3,5,4,7,5,8,9,7,10] },
    { label: "Available bench",    value: availableNow,         delta: "+14%", up: true, color: "green",  icon: ICO.resources, spark: [22,18,20,17,19,21,18,availableNow,availableNow+2] },
    { label: "Interviews this wk", value: D.ASSIGNMENTS.filter(a => a.status === "interview").length, delta: "-35%", up: false, color: "cyan", icon: ICO.user, spark: [9,7,8,6,5,4,5,4,3] },
    { label: "Match runs / day",   value: "4.9K",               delta: "+18%", up: true, color: "yellow", icon: ICO.spark, bars: [12,18,14,22,20,28,24,30,26,34,32,40] },
  ];

  const orderData = [
    { label: "Profiles shared", pct: 42, color: "#2196f3" },
    { label: "In interview",    pct: 18, color: "#00d68f" },
    { label: "Offers extended", pct: 9,  color: "#ffc107" },
    { label: "Filled",          pct: 22, color: "#ff7a00" },
    { label: "Lost / on hold",  pct: 9,  color: "#ff2c8a" },
  ];

  const salesData = [
    { month: "Jan", sales: 19, views: 17 },
    { month: "Feb", sales: 6,  views: 8 },
    { month: "Mar", sales: 58, views: 44 },
    { month: "Apr", sales: 9,  views: 14 },
    { month: "May", sales: 29, views: 26 },
    { month: "Jun", sales: 13, views: 13 },
    { month: "Jul", sales: 25, views: 40 },
    { month: "Aug", sales: 16, views: 8 },
    { month: "Sep", sales: 32, views: 24 },
  ];

  return (
    <div className="col gap-5">
      <div className="page-head">
        <div>
          <h1 className="page-title">Good morning, Hana</h1>
          <div className="page-sub">You have <b style={{color:"var(--text)"}}>3 interviews</b>, <b style={{color:"var(--text)"}}>2 profile decisions</b> waiting and <b style={{color:"var(--text)"}}>5 new requirements</b> this week.</div>
        </div>
        <div className="page-actions">
          <button className="btn"><Icon d={ICO.calendar} /> Week</button>
          <button className="btn"><Icon d={ICO.download} /> Export</button>
        </div>
      </div>

      {/* Row 1: Hero + 4 colorful stat cards */}
      <div style={{display:"grid", gridTemplateColumns:"1.3fr repeat(4, 1fr)", gap:14}}>
        <div className="hero-card">
          <div className="deco" />
          <div style={{position:"relative", zIndex: 1}}>
            <div className="text-lg bold" style={{fontSize:18, display:"flex", gap:8, alignItems:"center"}}>
              Congrats, Hana <span className="confetti">✦</span>
            </div>
            <div className="muted text-sm" style={{marginTop:2}}>Top resourcer of the month</div>
            <div className="num bold" style={{fontSize:30, marginTop:14, letterSpacing:"-.02em"}}>€168.5K</div>
            <div className="text-xs muted">68% of quarterly target</div>
          </div>
          <button className="cta" style={{marginTop:14}}>View details →</button>
        </div>

        {statCards.map((s, i) => (
          <div key={i} className="stat-color">
            <div className="top">
              <span className="icon-bubble" style={{background: `var(--grad-${s.color})`}}>
                <Icon d={s.icon} size={16} stroke="#fff" sw={2}/>
              </span>
              <span className={`delta ${s.up ? "up" : "down"}`}>
                {s.delta}
                <Icon d={s.up ? "M7 17l5-5 5 5" : "M7 7l5 5 5-5"} size={12} sw={2.5}/>
              </span>
            </div>
            <div className="value">{s.value}</div>
            <div className="label-row"><span>{s.label}</span></div>
            <div className="chart">
              {s.bars
                ? <MiniBars vals={s.bars} color={`url(#bars-${s.color})`} />
                : <GradSpark vals={s.spark} color={`var(--c-${s.color})`} gradId={`g-${s.color}`}/>}
              {s.bars && (
                <svg width="0" height="0" style={{position:"absolute"}}>
                  <defs>
                    <linearGradient id={`bars-${s.color}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ffc107"/>
                      <stop offset="100%" stopColor="#ff7a00"/>
                    </linearGradient>
                  </defs>
                </svg>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Row 2: Pipeline donut + bar chart */}
      <div style={{display:"grid", gridTemplateColumns:"1fr 2fr", gap:14}}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">Pipeline status</div>
            <Icon d={ICO.more} size={14} style={{marginLeft:"auto"}}/>
          </div>
          <div className="card-body col gap-2">
            <div className="donut-rainbow">
              <div className="center">
                <div className="pct">68%</div>
                <div className="lbl">conversion</div>
              </div>
            </div>
            {orderData.map(o => (
              <div key={o.label} className="legend-row">
                <span className="swatch" style={{background: o.color}}/>
                <span>{o.label}</span>
                <span className="pct">{o.pct}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">Submissions & Interviews</div>
            <span className="text-xs muted" style={{marginLeft:"auto"}}>2026 YTD</span>
            <Icon d={ICO.more} size={14}/>
          </div>
          <div className="card-body">
            <BarChart data={salesData}/>
            <div className="row gap-4" style={{justifyContent:"center", marginTop:8}}>
              <div className="row gap-2" style={{alignItems:"center"}}>
                <span style={{width:10,height:10,borderRadius:2,background:"var(--grad-orange)",display:"inline-block"}}/>
                <span className="text-xs">Profiles shared</span>
              </div>
              <div className="row gap-2" style={{alignItems:"center"}}>
                <span style={{width:10,height:10,borderRadius:2,background:"var(--grad-cyan)",display:"inline-block"}}/>
                <span className="text-xs">Interviews</span>
              </div>
            </div>
            <div className="row gap-4" style={{marginTop:14}}>
              <div className="row gap-3" style={{alignItems:"center", padding:"10px 14px", background:"var(--surface-2)", borderRadius:10, flex:1}}>
                <div className="mini-donut" style={{"--pct": 65, "--col": "var(--c-cyan)"}}/>
                <div className="col">
                  <div className="text-sm muted">This month</div>
                  <div className="num bold" style={{fontSize:22}}>65,127</div>
                  <div className="text-xs" style={{color:"#00d68f"}}>↑ 16.5% vs prev.</div>
                </div>
              </div>
              <div className="row gap-3" style={{alignItems:"center", padding:"10px 14px", background:"var(--surface-2)", borderRadius:10, flex:1}}>
                <div className="mini-donut" style={{"--pct": 78, "--col": "var(--c-yellow)"}}/>
                <div className="col">
                  <div className="text-sm muted">This year</div>
                  <div className="num bold" style={{fontSize:22}}>984,246</div>
                  <div className="text-xs" style={{color:"#00d68f"}}>↑ 24.9% YoY</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Action lists */}
      <div className="grid-2" style={{ gridTemplateColumns: "1.6fr 1fr" }}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">Requirements needing action</div>
            <span className="badge accent" style={{marginLeft:"auto"}}>{openProjects.length} open</span>
            <button className="btn sm ghost" onClick={() => onNav("projects")}>View all <Icon d={ICO.arrow} size={11} /></button>
          </div>
          <div>
            {openProjects.slice(0, 5).map(p => {
              const client = D.CLIENTS.find(c => c.id === p.client);
              const statusDef = D.PROJECT_STATUSES.find(s => s.id === p.status);
              const ass = D.ASSIGNMENTS.filter(a => a.project === p.id);
              return (
                <div key={p.id} className="row gap-3" style={{ padding: "12px 16px", borderTop: "1px solid var(--border)", alignItems:"center" }}>
                  <Avatar name={client.name} color={client.logoColor} />
                  <div className="col" style={{ flex: 1, minWidth: 0 }}>
                    <div className="text-sm bold ellipsis">{p.title}</div>
                    <div className="text-xs muted ellipsis">{client.name} · {p.roles} {p.roles>1?"roles":"role"} · {p.location}</div>
                  </div>
                  <div className="row" style={{ alignItems: "center" }}>
                    {ass.slice(0,3).map((a,i) => {
                      const r = D.RESOURCES.find(x => x.id === a.resource);
                      return <span key={a.id} title={r.name} style={{ marginLeft: i ? -10 : 0, zIndex: 3-i, boxShadow:"0 0 0 2px var(--surface)", borderRadius: "50%" }}><Avatar name={r.name} color={r.avatarColor} /></span>;
                    })}
                  </div>
                  <span className={`badge ${statusDef.color}`}><span className="dot" />{statusDef.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card">
          <div className="card-head"><div className="card-title">Today</div></div>
          <div style={{ padding: "4px 0" }}>
            {[
              { time: "10:00", what: "Client interview · Halberg", who: "Aanya Patel",  color: "#ffc107" },
              { time: "11:30", what: "Profile review · Northwind", who: "3 candidates", color: "#ff2c8a" },
              { time: "14:00", what: "Intake call · Verdant Ag",   who: "L. Bakker",    color: "#2196f3" },
              { time: "15:30", what: "Offer call · Aster",         who: "Sofia R.",     color: "#00d68f" },
              { time: "17:00", what: "Pipeline sync · internal",   who: "Team",         color: "#8a5cf6" },
            ].map((row, i) => (
              <div key={i} className="row gap-3" style={{ padding: "10px 16px", borderTop: i ? "1px solid var(--border)" : 0, alignItems: "center" }}>
                <span className="mono text-xs" style={{ width: 36 }}>{row.time}</span>
                <span style={{ width: 8, height: 8, borderRadius: "50%", background: row.color, flexShrink: 0 }}/>
                <div className="col" style={{ flex: 1, minWidth: 0 }}>
                  <div className="text-sm ellipsis">{row.what}</div>
                  <div className="text-xs muted ellipsis">{row.who}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

window.DashboardView = Dashboard;
