/* global React, UI, RMS_DATA */
const { useState, useMemo } = React;
const { Icon, ICO, MatchCircle, MatchBar, StatusBadge, Avatar } = window.UI;
const D = window.RMS_DATA;

function ProjectsView({ onOpenProject, layout }) {
  const [statusF, setStatusF] = useState("all");
  const [q, setQ] = useState("");
  const [view, setView] = useState(layout || "list"); // list | kanban

  const filtered = D.PROJECTS.filter(p => {
    if (statusF !== "all" && p.status !== statusF) return false;
    if (q && !p.title.toLowerCase().includes(q.toLowerCase()) && !p.skills.join(" ").toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="col gap-4">
      <div className="page-head">
        <div>
          <h1 className="page-title">Project requests</h1>
          <div className="page-sub">{D.PROJECTS.filter(p=>!["filled","lost"].includes(p.status)).length} active across {new Set(D.PROJECTS.map(p=>p.client)).size} clients</div>
        </div>
        <div className="page-actions">
          <button className="btn"><Icon d={ICO.download} /> Export</button>
          <button className="btn accent"><Icon d={ICO.plus} /> New requirement</button>
        </div>
      </div>

      <div className="row gap-3" style={{ alignItems:"center", flexWrap:"wrap" }}>
        <div className="search-box" style={{ width: 280, height: 32, color: "var(--text)" }}>
          <Icon d={ICO.search} size={12} />
          <input className="input" style={{ border: 0, padding: 0, height: "auto", background: "transparent" }}
                 placeholder="Search by title or skill…" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <div className="row gap-2" style={{ flexWrap: "wrap" }}>
          <button className={`chip ${statusF === "all" ? "" : ""}`} style={statusF==="all"?{background:"var(--text)",color:"#fff",borderColor:"var(--text)"}:undefined} onClick={() => setStatusF("all")}>All <span className="num" style={{opacity:0.7}}>{D.PROJECTS.length}</span></button>
          {D.PROJECT_STATUSES.map(s => {
            const ct = D.PROJECTS.filter(p => p.status === s.id).length;
            return (
              <button key={s.id} className="chip" style={statusF===s.id?{background:"var(--text)",color:"#fff",borderColor:"var(--text)"}:undefined} onClick={() => setStatusF(s.id)}>
                <span className={`dot ${s.color}`} />{s.label} <span className="num" style={{opacity:0.7}}>{ct}</span>
              </button>
            );
          })}
        </div>
        <div style={{ flex: 1 }} />
        <div className="role-switch">
          <button className={view === "list" ? "active" : ""} onClick={() => setView("list")}>List</button>
          <button className={view === "kanban" ? "active" : ""} onClick={() => setView("kanban")}>Pipeline</button>
        </div>
      </div>

      {view === "list" ? (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{width:"34%"}}>Requirement</th>
                <th>Client</th>
                <th className="right">Roles</th>
                <th>Rate</th>
                <th>Start</th>
                <th>Owner</th>
                <th>Status</th>
                <th>Priority</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => {
                const c = D.CLIENTS.find(x => x.id === p.client);
                return (
                  <tr key={p.id} className="clickable" onClick={() => onOpenProject(p)}>
                    <td>
                      <div className="col">
                        <span className="bold">{p.title}</span>
                        <div className="row gap-2" style={{marginTop:3, flexWrap:"wrap"}}>
                          {p.skills.slice(0,4).map(s => <span key={s} className="skill-tag">{s}</span>)}
                          {p.skills.length > 4 && <span className="text-xs muted">+{p.skills.length-4}</span>}
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="row gap-2" style={{ alignItems:"center" }}>
                        <Avatar name={c.name} color={c.logoColor} />
                        <span>{c.name}</span>
                      </div>
                    </td>
                    <td className="right num">{p.roles}</td>
                    <td className="mono text-xs">{p.rate}</td>
                    <td className="mono text-xs muted">{p.start}</td>
                    <td>{p.owner === "you" ? <span className="badge accent">You</span> : <span className="text-sm muted">{p.owner}</span>}</td>
                    <td><StatusBadge status={p.status} statuses={D.PROJECT_STATUSES} /></td>
                    <td>{p.priority === "high" ? <span className="badge danger"><span className="dot"/>High</span> : p.priority === "medium" ? <span className="badge warn"><span className="dot"/>Med</span> : <span className="badge neutral"><span className="dot"/>Low</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="pipeline">
          {D.PROJECT_STATUSES.filter(s => !["lost","hold"].includes(s.id)).map(s => {
            const items = D.PROJECTS.filter(p => p.status === s.id);
            return (
              <div key={s.id} className="pipeline-col">
                <header>
                  <span className={`dot ${s.color}`} />
                  <span>{s.label}</span>
                  <span className="text-xs muted" style={{marginLeft:"auto"}}>{items.length}</span>
                </header>
                <div className="col-body">
                  {items.map(p => {
                    const c = D.CLIENTS.find(x => x.id === p.client);
                    return (
                      <div key={p.id} className="kanban-card" onClick={() => onOpenProject(p)}>
                        <div className="row gap-2" style={{alignItems:"center", marginBottom:6}}>
                          <Avatar name={c.name} color={c.logoColor} />
                          <span className="text-xs muted">{c.name}</span>
                          <span style={{marginLeft:"auto"}} className="text-xs muted mono">{p.rate}</span>
                        </div>
                        <div className="text-sm bold" style={{marginBottom:6}}>{p.title}</div>
                        <div className="row gap-2" style={{flexWrap:"wrap"}}>
                          {p.skills.slice(0,3).map(sk => <span key={sk} className="skill-tag">{sk}</span>)}
                        </div>
                        <div className="row gap-2" style={{marginTop:8, alignItems:"center"}}>
                          <span className="text-xs muted">{p.roles} {p.roles>1?"roles":"role"}</span>
                          <span className="text-xs muted">·</span>
                          <span className="text-xs muted">{p.location}</span>
                          {p.priority === "high" && <span className="badge danger" style={{marginLeft:"auto"}}><span className="dot"/>P0</span>}
                        </div>
                      </div>
                    );
                  })}
                  {items.length === 0 && <div className="empty text-xs">No items</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

window.ProjectsView = ProjectsView;
