/* global React, UI, RMS_DATA */
const { useState, useEffect, useRef } = React;
const { Icon, ICO, Avatar } = window.UI;
const D = window.RMS_DATA;

/* ---------- Add Resource: resume upload → AI parse → form ---------- */
function AddResourceModal({ onClose, onCreated }) {
  const [step, setStep] = useState("upload"); // upload | parse | form | done
  const [drag, setDrag] = useState(false);
  const [parseProgress, setParseProgress] = useState(0);
  const [form, setForm] = useState(null);

  const parseSteps = [
    "Extracting text from resume.pdf",
    "Detecting contact information",
    "Parsing work history (3 roles found)",
    "Extracting skills via NER (9 skills)",
    "Normalizing seniority and rate",
    "Cross-referencing skill taxonomy",
  ];

  useEffect(() => {
    if (step === "parse") {
      let i = 0;
      const tick = () => {
        i++;
        setParseProgress(i);
        if (i < parseSteps.length) {
          setTimeout(tick, 320);
        } else {
          setTimeout(() => {
            setForm({ ...D.PARSED_RESUME });
            setStep("form");
          }, 350);
        }
      };
      setTimeout(tick, 350);
    }
  }, [step]);

  function dropResume(e) {
    e.preventDefault();
    setDrag(false);
    setStep("parse");
  }

  function update(k, v) { setForm(f => ({ ...f, [k]: v })); }

  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-card" onClick={e => e.stopPropagation()}>
        {/* Step indicator */}
        <div className="row gap-2" style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)", alignItems: "center" }}>
          <div className="row gap-2" style={{ flex: 1 }}>
            {[
              { id: "upload", n: 1, label: "Upload resume" },
              { id: "parse",  n: 2, label: "AI parse" },
              { id: "form",   n: 3, label: "Confirm details" },
              { id: "done",   n: 4, label: "Done" },
            ].map((s, i, arr) => {
              const curIdx = arr.findIndex(x => x.id === step);
              const active = s.id === step;
              const passed = i < curIdx;
              return (
                <React.Fragment key={s.id}>
                  <div className="row gap-2" style={{ alignItems: "center" }}>
                    <span style={{
                      width: 22, height: 22, borderRadius: "50%",
                      background: passed ? "var(--accent)" : active ? "var(--surface)" : "var(--surface-2)",
                      border: `1.5px solid ${active || passed ? "var(--accent)" : "var(--border)"}`,
                      color: passed ? "#fff" : active ? "var(--accent)" : "var(--text-3)",
                      fontSize: 11, fontWeight: 600,
                      display: "grid", placeItems: "center",
                    }}>{passed ? "✓" : s.n}</span>
                    <span className="text-sm" style={{ color: active ? "var(--text)" : passed ? "var(--text-2)" : "var(--text-3)", fontWeight: active ? 600 : 400 }}>{s.label}</span>
                  </div>
                  {i < arr.length - 1 && <div style={{ flex: 1, height: 1, background: passed ? "var(--accent)" : "var(--border)" }} />}
                </React.Fragment>
              );
            })}
          </div>
          <button className="btn ghost" onClick={onClose} style={{ width: 28, padding: 0, justifyContent: "center" }}><Icon d={ICO.x} /></button>
        </div>

        <div style={{ flex: 1, overflow: "auto" }}>
          {step === "upload" && (
            <div style={{ padding: 32 }}>
              <h2 style={{margin:"0 0 4px",fontSize:18,fontWeight:600,letterSpacing:"-.01em"}}>Start with a resume</h2>
              <p className="muted" style={{marginTop:0}}>Drop a CV file and we'll extract contact info, work history, skills and seniority. You can review everything before saving.</p>
              <div className={`upload-zone ${drag ? "drag" : ""}`}
                   onDragOver={e => { e.preventDefault(); setDrag(true); }}
                   onDragLeave={() => setDrag(false)}
                   onDrop={dropResume}
                   onClick={() => setStep("parse")}>
                <Icon d={ICO.upload} size={32} stroke="var(--text-3)" sw={1.4} />
                <div className="text-lg bold" style={{marginTop:12}}>Drop resume here</div>
                <div className="muted text-sm" style={{marginTop:4}}>or click to browse · PDF, DOCX, TXT up to 10 MB</div>
                <div className="row gap-2" style={{justifyContent:"center", marginTop:20}}>
                  <button className="btn" onClick={(e) => { e.stopPropagation(); setStep("parse"); }}>Use sample resume</button>
                  <button className="btn">Paste LinkedIn URL</button>
                </div>
              </div>
              <div className="row gap-3" style={{marginTop:20, justifyContent:"space-between"}}>
                <span className="text-xs muted">Bulk uploading? <a style={{color:"var(--accent)",textDecoration:"underline"}}>Import a folder →</a></span>
                <button className="btn ghost text-xs" onClick={() => setStep("form")}>Skip and enter manually →</button>
              </div>
            </div>
          )}

          {step === "parse" && (
            <div style={{ padding: 40, maxWidth: 480, margin: "0 auto" }}>
              <h2 style={{margin:"0 0 4px",fontSize:16,fontWeight:600}}>Parsing resume</h2>
              <p className="muted text-sm" style={{marginTop:0,marginBottom:24}}>Using OCR + NER to extract structured fields. Takes ~3 seconds.</p>
              {parseSteps.map((s, i) => {
                const state = i < parseProgress ? "done" : i === parseProgress ? "active" : "pending";
                return (
                  <div key={i} className={`parse-line ${state}`}>
                    {state === "done" && <Icon d={ICO.check} size={14} stroke="var(--ok)" />}
                    {state === "active" && (
                      <svg className="status" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                        <path d="M12 2a10 10 0 0 1 10 10" />
                      </svg>
                    )}
                    {state === "pending" && <span className="status" style={{ width: 14, height: 14, borderRadius: "50%", border: "1.5px solid var(--border)", display:"inline-block" }} />}
                    <span>{s}</span>
                  </div>
                );
              })}
            </div>
          )}

          {step === "form" && form && (
            <div className="row" style={{ height: 540 }}>
              {/* Resume preview */}
              <div style={{ width: 280, flexShrink: 0, borderRight: "1px solid var(--border)", padding: 16, background: "var(--surface-2)", overflow: "auto" }}>
                <div className="text-xs muted" style={{ textTransform: "uppercase", letterSpacing: ".06em" }}>Source resume</div>
                <div className="row gap-2" style={{ marginTop: 6, padding: 10, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 6 }}>
                  <Icon d={ICO.doc} />
                  <div className="col" style={{ flex: 1, minWidth: 0 }}>
                    <div className="text-sm bold ellipsis">{form.name.replace(" ","_")}_CV.pdf</div>
                    <div className="text-xs muted">248 KB · 2 pages</div>
                  </div>
                </div>
                <div style={{ marginTop: 12, padding: 16, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 6, fontSize: 11, lineHeight: 1.6, color: "var(--text-2)", fontFamily: "var(--font-mono)" }}>
                  <div className="bold" style={{color:"var(--text)",marginBottom:4}}>{form.name}</div>
                  <div>{form.role}</div>
                  <div>{form.location} · {form.email}</div>
                  <hr style={{margin:"8px 0", border:0, borderTop:"1px dashed var(--border)"}}/>
                  <div className="bold" style={{color:"var(--text)"}}>EXPERIENCE</div>
                  {form.experience.map((e, i) => (
                    <div key={i} style={{marginTop:4}}>
                      <div>{e.role}</div>
                      <div className="muted">{e.co} · {e.from}–{e.to}</div>
                    </div>
                  ))}
                  <hr style={{margin:"8px 0", border:0, borderTop:"1px dashed var(--border)"}}/>
                  <div className="bold" style={{color:"var(--text)"}}>SKILLS</div>
                  <div>{form.skills.join(", ")}</div>
                  <hr style={{margin:"8px 0", border:0, borderTop:"1px dashed var(--border)"}}/>
                  <div className="bold" style={{color:"var(--text)"}}>EDUCATION</div>
                  <div>{form.education}</div>
                </div>
              </div>

              {/* Form */}
              <div style={{ flex: 1, padding: 24, overflow: "auto" }}>
                <div className="row gap-2" style={{ alignItems: "center", marginBottom: 4 }}>
                  <h2 style={{margin:0,fontSize:16,fontWeight:600}}>Review & confirm</h2>
                  <span className="badge accent" style={{marginLeft:6}}><span className="dot"/>9 fields auto-filled</span>
                </div>
                <p className="muted text-sm" style={{marginTop:0,marginBottom:16}}>Highlighted fields were extracted from the resume. Edit anything that looks off.</p>

                <div className="form-grid">
                  <div className="field parsed">
                    <label>Full name</label>
                    <input className="input" value={form.name} onChange={e => update("name", e.target.value)} />
                  </div>
                  <div className="field parsed">
                    <label>Email</label>
                    <input className="input" value={form.email} onChange={e => update("email", e.target.value)} />
                  </div>
                  <div className="field parsed">
                    <label>Phone</label>
                    <input className="input" value={form.phone} onChange={e => update("phone", e.target.value)} />
                  </div>
                  <div className="field parsed">
                    <label>Location</label>
                    <input className="input" value={form.location} onChange={e => update("location", e.target.value)} />
                  </div>
                  <div className="field parsed">
                    <label>Primary role</label>
                    <input className="input" value={form.role} onChange={e => update("role", e.target.value)} />
                  </div>
                  <div className="field parsed">
                    <label>Seniority</label>
                    <select className="input" value={form.seniority} onChange={e => update("seniority", e.target.value)}>
                      {D.SENIORITIES.map(s => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                  <div className="field parsed">
                    <label>Years of experience</label>
                    <input className="input" type="number" value={form.yrs} onChange={e => update("yrs", +e.target.value)} />
                  </div>
                  <div className="field">
                    <label>Notice period (weeks)</label>
                    <input className="input" type="number" defaultValue={4} />
                  </div>
                  <div className="field parsed">
                    <label>Day rate</label>
                    <input className="input" type="number" value={form.rate} onChange={e => update("rate", +e.target.value)} />
                  </div>
                  <div className="field parsed">
                    <label>Currency</label>
                    <select className="input" value={form.currency} onChange={e => update("currency", e.target.value)}>
                      <option>EUR/d</option><option>GBP/d</option><option>USD/hr</option><option>CHF/d</option>
                    </select>
                  </div>
                  <div className="field full parsed">
                    <label>Skills ({form.skills.length})</label>
                    <div className="row gap-2" style={{ flexWrap: "wrap", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: 6, background: "oklch(0.97 0.04 95)", borderColor:"oklch(0.85 0.10 95)" }}>
                      {form.skills.map(s => (
                        <span key={s} className="chip removable">{s}
                          <span className="x" onClick={() => update("skills", form.skills.filter(x => x !== s))}>×</span>
                        </span>
                      ))}
                      <input className="input" style={{ border: 0, padding: 0, height: 22, background: "transparent", width: 120 }} placeholder="+ add skill" onKeyDown={e => {
                        if (e.key === "Enter" && e.target.value) { update("skills", [...form.skills, e.target.value]); e.target.value = ""; }
                      }} />
                    </div>
                  </div>
                  <div className="field full parsed">
                    <label>Summary</label>
                    <textarea className="input" rows={3} value={form.summary} onChange={e => update("summary", e.target.value)} style={{height:"auto",padding:"8px 10px"}}/>
                  </div>
                  <div className="field full parsed">
                    <label>Languages</label>
                    <div className="row gap-2" style={{ padding: 4 }}>
                      {form.languages.map(l => <span key={l} className="chip">{l}</span>)}
                    </div>
                  </div>
                  <div className="field full">
                    <label>Internal tags</label>
                    <input className="input" placeholder="Comma-separated tags (e.g. Top performer, Security cleared)" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === "done" && (
            <div style={{ padding: 60, textAlign: "center" }}>
              <div style={{ width: 64, height: 64, margin: "0 auto", borderRadius: "50%", background: "var(--ok-soft)", display: "grid", placeItems: "center" }}>
                <Icon d={ICO.check} size={28} stroke="var(--ok)" sw={2.5}/>
              </div>
              <h2 style={{margin:"16px 0 4px",fontSize:18,fontWeight:600}}>Resource added</h2>
              <p className="muted">{form?.name} is now on the bench. We auto-matched them against 3 open projects.</p>
              <div className="row gap-2" style={{justifyContent:"center",marginTop:20}}>
                <button className="btn" onClick={onClose}>Add another</button>
                <button className="btn accent" onClick={() => { onCreated(form); onClose(); }}>View profile →</button>
              </div>
            </div>
          )}
        </div>

        {(step === "form" || step === "upload") && (
          <div className="drawer-foot">
            {step === "form" && <button className="btn" onClick={() => setStep("upload")}>← Back</button>}
            <div style={{flex:1}}/>
            <button className="btn" onClick={onClose}>Cancel</button>
            {step === "form" && (
              <button className="btn accent" onClick={() => setStep("done")}>
                <Icon d={ICO.check}/> Save resource
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

window.AddResourceModal = AddResourceModal;
