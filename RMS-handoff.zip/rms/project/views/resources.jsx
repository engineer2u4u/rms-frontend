/* global React, UI, RMS_DATA */
const { useState, useMemo, useEffect } = React;
const { Icon, ICO, MatchCircle, MatchBar, StatusBadge, Avatar } = window.UI;
const D = window.RMS_DATA;

function ResourcesView({ onOpenResource, matchProject, setMatchProject, matchStyle, layout }) {
  const [skills, setSkills] = useState([]);
  const [seniority, setSeniority] = useState([]);
  const [status, setStatus] = useState([]);
  const [minYrs, setMinYrs] = useState(0);
  const [minMatch, setMinMatch] = useState(0);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState({ key: matchProject ? "match" : "name", dir: "desc" });
  const [view, setView] = useState(layout || "table"); // table | cards | split

  useEffect(() => {
    if (matchProject) setSort({ key: "match", dir: "desc" });
  }, [matchProject]);

  // top skills by frequency for the filter rail
  const topSkills = useMemo(() => {
    const cts = {};
    D.RESOURCES.forEach(r => r.skills.forEach(s => { cts[s] = (cts[s] || 0) + 1; }));
    return Object.entries(cts).sort((a, b) => b[1] - a[1]).slice(0, 14);
  }, []);

  const project = matchProject ? D.PROJECTS.find(p => p.id === matchProject) : null;

  const scored = useMemo(() => D.RESOURCES.map(r => ({
    ...r, _match: project ? D.matchScore(r, project) : null
  })), [matchProject]);

  const filtered = useMemo(() => {
    let out = scored.filter(r => {
      if (q && !(r.name + " " + r.role + " " + r.skills.join(" ")).toLowerCase().includes(q.toLowerCase())) return false;
      if (skills.length && !skills.every(s => r.skills.includes(s))) return false;
      if (seniority.length && !seniority.includes(r.seniority)) return false;
      if (status.length && !status.includes(r.status)) return false;
      if (minYrs && r.yrs < minYrs) return false;
      if (minMatch && (!r._match || r._match.total < minMatch)) return false;
      return true;
    });
    out.sort((a, b) => {
      const dir = sort.dir === "asc" ? 1 : -1;
      if (sort.key === "match")  return dir * ((b._match?.total || 0) - (a._match?.total || 0));
      if (sort.key === "yrs")    return dir * (b.yrs - a.yrs);
      if (sort.key === "rate")   return dir * (b.rate - a.rate);
      if (sort.key === "avail")  return dir * (a.availableIn - b.availableIn);
      return dir * (a.name > b.name ? -1 : 1);
    });
    return out;
  }, [scored, q, skills, seniority, status, minYrs, minMatch, sort]);

  function toggle(arr, set, v) { set(arr.includes(v) ? arr.filter(x => x !== v) : [...arr, v]); }

  function sortable(key, label, align) {
    const active = sort.key === key;
    return (
      <th className={"sortable " + (active ? "active" : "") + (align === "right" ? " right" : "")}
          style={align === "right" ? { textAlign: "right" } : undefined}
          onClick={() => setSort({ key, dir: active && sort.dir === "desc" ? "asc" : "desc" })}>
        <span>{label}</span> <span className="arrow">{active ? (sort.dir === "desc" ? "▼" : "▲") : "↕"}</span>
      </th>
    );
  }

  function MatchView({ m }) {
    if (!m) return <span className="muted text-xs">—</span>;
    if (matchStyle === "bar")    return <div style={{width:100}}><MatchBar score={m.total} /></div>;
    if (matchStyle === "chip") {
      const tone = m.total >= 80 ? "ok" : m.total >= 60 ? "accent" : m.total >= 45 ? "warn" : "danger";
      return <span className={`badge ${tone}`}><span className="dot"/>{m.total}% match</span>;
    }
    return <MatchCircle score={m.total} />;
  }

  return (
    <div className="col gap-4">
      <div className="page-head">
        <div>
          <h1 className="page-title">Resources</h1>
          <div className="page-sub">
            {filtered.length} of {D.RESOURCES.length} people{project ? <> · matched against <b style={{color:"var(--text)"}}>{project.title}</b></> : null}
          </div>
        </div>
        <div className="page-actions">
          <button className="btn"><Icon d={ICO.upload} /> Import CSV</button>
          <button className="btn"><Icon d={ICO.download} /> Export</button>
          <button className="btn accent"><Icon d={ICO.plus} /> Add resource</button>
        </div>
      </div>

      {/* Match-to context bar */}
      <div className="card" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px" }}>
        <Icon d={ICO.spark} />
        <span className="text-sm bold">Match against project</span>
        <select className="input" style={{ height: 28, maxWidth: 360 }} value={matchProject || ""} onChange={e => setMatchProject(e.target.value || null)}>
          <option value="">— None (browse all) —</option>
          {D.PROJECTS.filter(p => !["filled","lost"].includes(p.status)).map(p => {
            const c = D.CLIENTS.find(x => x.id === p.client);
            return <option key={p.id} value={p.id}>{c.name} · {p.title}</option>;
          })}
        </select>
        {project && (
          <>
            <div className="row gap-2" style={{ flexWrap: "wrap" }}>
              {project.skills.map(s => <span key={s} className="skill-tag match">{s}</span>)}
            </div>
            <div style={{ flex: 1 }} />
            <span className="text-xs muted">Sort by match</span>
          </>
        )}
      </div>

      <div className="row gap-4" style={{ alignItems: "flex-start" }}>
        {/* ---- Filter rail ---- */}
        <aside className="filter-rail">
          <details className="filter-group" open>
            <summary><Icon d={ICO.search} size={12} /> Quick search <Icon d={ICO.caret} size={12} style={{marginLeft:"auto", transform:"rotate(0)"}} /></summary>
            <div className="filter-body">
              <input className="input" placeholder="Name, role, skill…" value={q} onChange={e => setQ(e.target.value)} />
            </div>
          </details>

          {project && (
            <details className="filter-group" open>
              <summary>Match score {minMatch>0 && <span className="pill">≥ {minMatch}%</span>} <Icon d={ICO.caret} size={12} className="caret" /></summary>
              <div className="filter-body">
                <input type="range" min="0" max="95" step="5" value={minMatch} onChange={e => setMinMatch(Number(e.target.value))} style={{ accentColor: "var(--accent)" }} />
                <div className="row" style={{justifyContent:"space-between"}}>
                  <span className="text-xs muted">0%</span>
                  <span className="text-xs mono bold">{minMatch}%</span>
                  <span className="text-xs muted">95%</span>
                </div>
              </div>
            </details>
          )}

          <details className="filter-group" open>
            <summary>Skills {skills.length > 0 && <span className="pill">{skills.length}</span>} <Icon d={ICO.caret} size={12} className="caret" /></summary>
            <div className="filter-body">
              {topSkills.map(([s, ct]) => (
                <label key={s} className="checkbox-row">
                  <input type="checkbox" checked={skills.includes(s)} onChange={() => toggle(skills, setSkills, s)} />
                  <span>{s}</span><span className="ct">{ct}</span>
                </label>
              ))}
            </div>
          </details>

          <details className="filter-group" open>
            <summary>Seniority {seniority.length > 0 && <span className="pill">{seniority.length}</span>} <Icon d={ICO.caret} size={12} className="caret" /></summary>
            <div className="filter-body">
              {D.SENIORITIES.map(s => {
                const ct = D.RESOURCES.filter(r => r.seniority === s).length;
                return (
                  <label key={s} className="checkbox-row">
                    <input type="checkbox" checked={seniority.includes(s)} onChange={() => toggle(seniority, setSeniority, s)} />
                    <span>{s}</span><span className="ct">{ct}</span>
                  </label>
                );
              })}
            </div>
          </details>

          <details className="filter-group" open>
            <summary>Availability {status.length > 0 && <span className="pill">{status.length}</span>} <Icon d={ICO.caret} size={12} className="caret" /></summary>
            <div className="filter-body">
              {D.STATUSES.map(s => {
                const ct = D.RESOURCES.filter(r => r.status === s.id).length;
                return (
                  <label key={s.id} className="checkbox-row">
                    <input type="checkbox" checked={status.includes(s.id)} onChange={() => toggle(status, setStatus, s.id)} />
                    <span className={`dot ${s.color}`} style={{marginRight:2}}/><span>{s.label}</span><span className="ct">{ct}</span>
                  </label>
                );
              })}
            </div>
          </details>

          <details className="filter-group" open>
            <summary>Min experience {minYrs > 0 && <span className="pill">{minYrs}y</span>} <Icon d={ICO.caret} size={12} className="caret" /></summary>
            <div className="filter-body">
              <input type="range" min="0" max="15" step="1" value={minYrs} onChange={e => setMinYrs(Number(e.target.value))} style={{ accentColor: "var(--accent)" }}/>
              <div className="row" style={{justifyContent:"space-between"}}>
                <span className="text-xs muted">0y</span>
                <span className="text-xs mono bold">{minYrs}+ yrs</span>
                <span className="text-xs muted">15+y</span>
              </div>
            </div>
          </details>

          <div style={{padding:"8px 10px", display:"flex", gap:6}}>
            <button className="btn sm" style={{flex:1}} onClick={() => { setSkills([]); setSeniority([]); setStatus([]); setMinYrs(0); setMinMatch(0); setQ(""); }}>Clear all</button>
            <button className="btn sm">Save view</button>
          </div>
        </aside>

        {/* ---- Results ---- */}
        <div className="flex-grow col gap-3" style={{ minWidth: 0 }}>
          <div className="row gap-2" style={{ alignItems: "center" }}>
            <span className="text-sm muted">{filtered.length} results</span>
            <div className="row gap-2" style={{ flexWrap: "wrap" }}>
              {[...skills, ...seniority.map(s => `Seniority: ${s}`), ...status.map(s => `Avail: ${D.STATUSES.find(x => x.id === s).label}`)].map(t =>
                <span key={t} className="chip removable">{t}<span className="x" onClick={(e) => { e.stopPropagation(); /* lazy remove */ }}>×</span></span>
              )}
            </div>
            <div style={{ flex: 1 }} />
            <div className="role-switch">
              <button className={view === "table" ? "active" : ""} onClick={() => setView("table")}>Table</button>
              <button className={view === "cards" ? "active" : ""} onClick={() => setView("cards")}>Cards</button>
            </div>
          </div>

          {view === "table" ? (
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Person</th>
                    <th>Skills</th>
                    {sortable("yrs", "Exp", "right")}
                    <th>Availability</th>
                    <th>Location</th>
                    {sortable("rate", "Rate")}
                    <th>Status</th>
                    {sortable("match", "Match", "right")}
                  </tr>
                </thead>
                <tbody>
                  {filtered.slice(0, 40).map(r => {
                    const stDef = D.STATUSES.find(s => s.id === r.status);
                    return (
                      <tr key={r.id} className="clickable" onClick={() => onOpenResource(r)}>
                        <td>
                          <div className="row gap-2" style={{ alignItems: "center" }}>
                            <Avatar name={r.name} color={r.avatarColor} />
                            <div className="col">
                              <span className="bold">{r.name}</span>
                              <span className="text-xs muted">{r.seniority} · {r.role}</span>
                            </div>
                          </div>
                        </td>
                        <td>
                          <div className="row gap-2" style={{ flexWrap: "wrap", maxWidth: 280 }}>
                            {r.skills.slice(0, 4).map(s => {
                              const matched = project && project.skills.some(ps => ps.toLowerCase() === s.toLowerCase());
                              return <span key={s} className={`skill-tag ${matched ? "match" : ""}`}>{s}</span>;
                            })}
                            {r.skills.length > 4 && <span className="text-xs muted">+{r.skills.length - 4}</span>}
                          </div>
                        </td>
                        <td className="right num">{r.yrs}y</td>
                        <td><span className="text-xs">{r.availability}</span></td>
                        <td className="text-xs muted">{r.location}</td>
                        <td className="mono text-xs">{r.rate} <span className="muted">{r.currency}</span></td>
                        <td><span className={`badge ${stDef.color}`}><span className="dot"/>{stDef.label}</span></td>
                        <td className="right"><MatchView m={r._match} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid-3">
              {filtered.slice(0, 24).map(r => {
                const stDef = D.STATUSES.find(s => s.id === r.status);
                return (
                  <button key={r.id} className="card" style={{ textAlign: "left", padding: 16, cursor: "pointer", display:"flex", flexDirection:"column", gap:10 }} onClick={() => onOpenResource(r)}>
                    <div className="row gap-3" style={{ alignItems: "center" }}>
                      <Avatar name={r.name} color={r.avatarColor} size="lg" />
                      <div className="col" style={{ flex: 1 }}>
                        <div className="bold">{r.name}</div>
                        <div className="text-xs muted">{r.seniority} · {r.role}</div>
                      </div>
                      {r._match && <MatchView m={r._match} />}
                    </div>
                    <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                      {r.skills.slice(0, 5).map(s => {
                        const matched = project && project.skills.some(ps => ps.toLowerCase() === s.toLowerCase());
                        return <span key={s} className={`skill-tag ${matched ? "match" : ""}`}>{s}</span>;
                      })}
                    </div>
                    <div className="row gap-3" style={{ alignItems: "center", marginTop: "auto" }}>
                      <span className="text-xs muted">{r.yrs}y · {r.location}</span>
                      <span className={`badge ${stDef.color}`} style={{marginLeft:"auto"}}><span className="dot"/>{stDef.label}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

window.ResourcesView = ResourcesView;
